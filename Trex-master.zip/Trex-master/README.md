# Trex
Trex game created using p5.play
